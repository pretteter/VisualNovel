# FUDGE_Story

A FUDGE module for the easy development of interactive stories, visual novels and simple adventure games

# Reference

- [APIs](https://jirkadelloro.github.io/FUDGE_Story/Documentation/Reference/#fudge-story-reference)

# Links
 ## Github Pages Link (lauffähige Anwendung)
- [GAME](https://pretteter.github.io/VisualNovel/myStory/myStory.html)
## Konzept Dokument
- [Konzept](https://pretteter.github.io/VisualNovel/Konzeptdokument.pdf)
## gepacktes Archiv
- [Archiv](https://github.com/pretteter/VisualNovel/raw/main/komplettes_Archiv.zip)
  <br>