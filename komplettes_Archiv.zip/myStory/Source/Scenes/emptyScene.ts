namespace myStory {
  export async function EmptyScene(): ƒS.SceneReturn {
    showCredits();
  }
}
